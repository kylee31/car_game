

#pragma once

void InitCarModel();
void DrawCarModel();
void DeleteCarModel();

