

#pragma once

void InitTreeModel();
void DrawTreeModel();
void DeleteTreeModel();

