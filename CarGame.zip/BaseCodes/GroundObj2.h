#pragma once

void InitGround2();
void DrawGround2();
void DeleteGround2();
