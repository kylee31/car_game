#pragma once
#include <string>

unsigned int CreateFromFiles(const std::string &v_shader_file, const std::string &f_shader_file);
